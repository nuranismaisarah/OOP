package view;

import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Color;

public class CustAcc extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args,int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CustAcc frame = new CustAcc(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CustAcc(int customerID) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCustAcc = new JLabel("CUSTOMER ACCOUNT");
		lblCustAcc.setBackground(new Color(255, 255, 128));
		lblCustAcc.setOpaque(true);
		lblCustAcc.setVerticalAlignment(SwingConstants.TOP);
		lblCustAcc.setFont(new Font("Sylfaen", Font.PLAIN, 33));
		lblCustAcc.setBounds(125, 73, 353, 33);
		contentPane.add(lblCustAcc);
		
		JButton btnTicketDetails = new JButton("TICKET DETAILS");
		btnTicketDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TicketPage frame = new TicketPage(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnTicketDetails.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		btnTicketDetails.setBounds(176, 232, 261, 39);
		contentPane.add(btnTicketDetails);
		
		JButton btnAccountDetails = new JButton("ACCOUNT DETAILS");
		btnAccountDetails.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AccDetailUpdate frame = new AccDetailUpdate(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnAccountDetails.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		btnAccountDetails.setBounds(173, 145, 264, 39);
		contentPane.add(btnAccountDetails);
		
		JButton btnLogOut = new JButton("LOG OUT");
		btnLogOut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage frame = new MainPage();
				frame.setVisible(true);
				dispose();
			}
		});
		btnLogOut.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		btnLogOut.setBounds(176, 318, 264, 39);
		contentPane.add(btnLogOut);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(0, 0, 592, 498);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		contentPane.add(lblNewLabel);
		
	}
}
