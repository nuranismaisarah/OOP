package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class AccDetailUpdate extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args, int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccDetailUpdate frame = new AccDetailUpdate(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AccDetailUpdate(int customerID) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("  ACCOUNT DETAILS");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(255, 255, 128));
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 32));
		lblNewLabel.setBounds(137, 32, 332, 70);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("UPDATE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AccDetailsUpdate2 frame = new AccDetailsUpdate2(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 25));
		btnNewButton.setBounds(222, 156, 141, 44);
		contentPane.add(btnNewButton);
		
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AccDetailsDelete frame = new AccDetailsDelete(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnDelete.setFont(new Font("Sylfaen", Font.BOLD, 25));
		btnDelete.setBounds(222, 260, 141, 44);
		contentPane.add(btnDelete);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustAcc frame = new CustAcc(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnBack.setFont(new Font("Sylfaen", Font.BOLD, 25));
		btnBack.setBounds(222, 371, 141, 44);
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		lblNewLabel_1.setBounds(0, 0, 592, 514);
		contentPane.add(lblNewLabel_1);
	}

}
