package view;

import java.sql.*;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.CustomerController;
import model.Customer;

import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginGUI frame = new LoginGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginGUI() {
		setAlwaysOnTop(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel LOGIN = new JLabel("LOGIN PAGE");
		LOGIN.setHorizontalAlignment(SwingConstants.CENTER);
		LOGIN.setBackground(new Color(255, 255, 128));
		LOGIN.setOpaque(true);
		LOGIN.setVerticalAlignment(SwingConstants.TOP);
		LOGIN.setFont(new Font("Sylfaen", Font.PLAIN, 36));
		LOGIN.setBounds(212, 133, 236, 40);
		contentPane.add(LOGIN);
		
		JLabel lblNewLabel = new JLabel("EMAIL :");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setBackground(new Color(255, 255, 128));
		lblNewLabel.setOpaque(true); 
		lblNewLabel.setFont(new Font("Sylfaen", Font.PLAIN, 25));
		lblNewLabel.setBounds(77, 207, 107, 23);
		contentPane.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("PASSWORD :");
		lblPassword.setHorizontalAlignment(SwingConstants.CENTER);
		lblPassword.setVerticalAlignment(SwingConstants.TOP);
		lblPassword.setLabelFor(lblPassword);
		lblPassword.setBackground(new Color(255, 255, 128));
		lblPassword.setOpaque(true);
		lblPassword.setFont(new Font("Sylfaen", Font.PLAIN, 25));
		lblPassword.setBounds(26, 265, 164, 23);
		contentPane.add(lblPassword);
		
		JTextPane txtEmail = new JTextPane();
		txtEmail.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtEmail.setBounds(212, 197, 236, 40);
		contentPane.add(txtEmail);
		
		JTextPane txtPassword = new JTextPane();
		txtPassword.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtPassword.setBounds(212, 255, 236, 40);
		contentPane.add(txtPassword);
		
		JButton btnOK = new JButton("OK");
		btnOK.setVerticalAlignment(SwingConstants.TOP);
		btnOK.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				Customer customer = new Customer();
				
				String email = txtEmail.getText();
				String password = new String (txtPassword.getText()).trim();
				
				customer.setEmail(email);
				customer.setPassword(password);
				
				CustomerController customerController = new CustomerController();
				
				try {
					
					int customerID = customerController.doLogin(customer);
					
					if(customerID == 0)
					{
						
						JOptionPane.showMessageDialog(btnOK,"Login Failed!" );
						
					}
					else
					{
						JOptionPane.showMessageDialog(btnOK,"Login Success!" );
						CustAcc frame = new CustAcc(customerID);
						frame.setVisible(true);
						
						dispose();
						
					}
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		});
		btnOK.setBounds(317, 328, 89, 29);
		contentPane.add(btnOK);
		
		JButton btnCancel = new JButton("CANCEL");
		btnCancel.setVerticalAlignment(SwingConstants.TOP);
		btnCancel.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		btnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainPage frame = new MainPage();
				frame.setVisible(true);
				dispose();
			}
		});
		btnCancel.setBounds(126, 328, 132, 31);
		contentPane.add(btnCancel);
		
		JLabel BACKGROUND = new JLabel("New label");
		BACKGROUND.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		BACKGROUND.setBounds(0, 0, 588, 498);
		contentPane.add(BACKGROUND);
	}
}
