package view;

import java.awt.Font;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.TicketController;
import model.Ticket;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;

public class DelTicketPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private JButton btnDelete;
    private TicketController ticketController;
    private DefaultTableModel tableModel;
    private int customerID; // Assuming you have a variable for the logged-in customer
    private JButton btnNewButton;
    private JLabel lblNewLabel_1;
    private JLabel lblNewLabel_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args,int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DelTicketPage frame = new DelTicketPage(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

    /**
     * Create the frame.
     */
    public DelTicketPage(int customerID) {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 606, 535);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("DELETE TICKET PAGE");
        lblNewLabel.setBounds(176, 26, 246, 33);
        lblNewLabel.setOpaque(true);
        lblNewLabel.setBackground(new Color(255, 255, 128));
        lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 22));
        contentPane.add(lblNewLabel);

        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(31, 162, 521, 241);
        contentPane.add(scrollPane);

        tableModel = new DefaultTableModel(
                new Object[][] {},
                new String[] { "Ticket ID", "Adult", "Senior", "Children","Amount", "Date" }
        );
        table = new JTable(tableModel);
        scrollPane.setViewportView(table);

        btnDelete = new JButton("DELETE");
        btnDelete.setBounds(96, 414, 153, 33);
        btnDelete.setEnabled(false);
        btnDelete.setFont(new Font("Sylfaen", Font.PLAIN, 18));
        btnDelete.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                deleteSelectedTicket();
            }
        });
        contentPane.add(btnDelete);
        
        btnNewButton = new JButton("BACK");
        btnNewButton.setBounds(324, 414, 153, 33);
        btnNewButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		TicketPage frame = new TicketPage(customerID);
				frame.setVisible(true);
				dispose();
        	}
        });
        btnNewButton.setFont(new Font("Sylfaen", Font.PLAIN, 18));
        contentPane.add(btnNewButton);
        
        lblNewLabel_1 = new JLabel("PLEASE SELECT TICKET TO DELETE !");
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setBounds(119, 103, 384, 22);
        lblNewLabel_1.setOpaque(true);
        lblNewLabel_1.setBackground(new Color(255, 255, 128));
        lblNewLabel_1.setFont(new Font("Sylfaen", Font.PLAIN, 21));
        contentPane.add(lblNewLabel_1);
        
        lblNewLabel_2 = new JLabel("New label");
        lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
        lblNewLabel_2.setBounds(0, -12, 602, 520);
        contentPane.add(lblNewLabel_2);

        this.customerID = customerID; // Set the customer ID

        ticketController = new TicketController();
        populateTable();

        // Add a listener to enable/disable the delete button based on row selection
        table.getSelectionModel().addListSelectionListener(e -> {
            btnDelete.setEnabled(table.getSelectedRow() != -1);
        });
    }

    // Method to populate the table with ticket information
    private void populateTable() {
        try {
            List<Ticket> tickets = ticketController.viewTicket(customerID);

            for (Ticket ticket : tickets) {
                Object[] row = { ticket.getTicketID(), ticket.getAdult(), ticket.getSenior(), ticket.getChildren(), ticket.getAmount(),
                        ticket.getDate() };
                tableModel.addRow(row);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to delete the selected ticket
    private void deleteSelectedTicket() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow != -1) {
            int ticketID = (int) tableModel.getValueAt(selectedRow, 0);

            try {
                ticketController.deleteTicket(ticketID);
                // Remove the row from the table model
                tableModel.removeRow(selectedRow);
            } catch (ClassNotFoundException | SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
