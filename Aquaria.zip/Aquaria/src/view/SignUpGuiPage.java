package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import controller.CustomerController;
import model.Customer;

public class SignUpGuiPage extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtPhone;
    private JTextField txtEmail;
    private JTextField txtName;
    private JTextField txtPassword;
    private JButton btnSubmit; // Move this declaration here

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SignUpGuiPage frame = new SignUpGuiPage();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public SignUpGuiPage() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 606, 535);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblNewLabel = new JLabel("SIGN UP PAGE ");
        lblNewLabel.setOpaque(true);
        lblNewLabel.setBackground(new Color(255, 255, 128));
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 36));
        lblNewLabel.setBounds(163, 63, 287, 36);
        contentPane.add(lblNewLabel);

        JLabel lblNewLabel_1 = new JLabel("NAME : ");
        lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_1.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_1.setBackground(new Color(255, 255, 128));
        lblNewLabel_1.setOpaque(true);
        lblNewLabel_1.setForeground(new Color(0, 0, 0));
        lblNewLabel_1.setFont(new Font("Sylfaen", Font.PLAIN, 24));
        lblNewLabel_1.setBounds(103, 170, 95, 25);
        contentPane.add(lblNewLabel_1);

        JLabel lblNewLabel_2 = new JLabel("EMAIL :");
        lblNewLabel_2.setBackground(new Color(255, 255, 128));
        lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_2.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_2.setOpaque(true);
        lblNewLabel_2.setFont(new Font("Sylfaen", Font.PLAIN, 24));
        lblNewLabel_2.setBounds(91, 241, 107, 25);
        contentPane.add(lblNewLabel_2);

        JLabel lblpassword = new JLabel("PASSWORD :");
        lblpassword.setHorizontalAlignment(SwingConstants.CENTER);
        lblpassword.setVerticalAlignment(SwingConstants.TOP);
        lblpassword.setBackground(new Color(255, 255, 128));
        lblpassword.setOpaque(true);
        lblpassword.setFont(new Font("Sylfaen", Font.PLAIN, 24));
        lblpassword.setBounds(44, 312, 154, 27);
        contentPane.add(lblpassword);

        JLabel lblNewLabel_2_2 = new JLabel("NO PHONE :");
        lblNewLabel_2_2.setBackground(new Color(255, 255, 128));
        lblNewLabel_2_2.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel_2_2.setVerticalAlignment(SwingConstants.TOP);
        lblNewLabel_2_2.setOpaque(true);
        lblNewLabel_2_2.setFont(new Font("Sylfaen", Font.PLAIN, 24));
        lblNewLabel_2_2.setBounds(52, 375, 146, 25);
        contentPane.add(lblNewLabel_2_2);

        txtPassword = new JTextField();
        txtPassword.setHorizontalAlignment(SwingConstants.CENTER);
        txtPassword.setFont(new Font("Sylfaen", Font.PLAIN, 22));
        txtPassword.setBounds(220, 301, 287, 36);
        contentPane.add(txtPassword);
        txtPassword.setColumns(10);

        txtEmail = new JTextField();
        txtEmail.setHorizontalAlignment(SwingConstants.CENTER);
        txtEmail.setFont(new Font("Sylfaen", Font.PLAIN, 22));
        txtEmail.setColumns(10);
        txtEmail.setBounds(220, 232, 287, 36);
        contentPane.add(txtEmail);

        txtName = new JTextField();
        txtName.setHorizontalAlignment(SwingConstants.CENTER);
        txtName.setFont(new Font("Sylfaen", Font.PLAIN, 22));
        txtName.setColumns(10);
        txtName.setBounds(220, 160, 287, 36);
        contentPane.add(txtName);

        txtPhone = new JTextField();
        txtPhone.setHorizontalAlignment(SwingConstants.CENTER);
        txtPhone.setFont(new Font("Sylfaen", Font.PLAIN, 22));
        txtPhone.setColumns(10);
        txtPhone.setBounds(220, 364, 287, 36);
        contentPane.add(txtPhone);

        JButton btnBack = new JButton("BACK");
        btnBack.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MainPage frame = new MainPage();
                frame.setVisible(true);
                dispose();
            }
        });
        btnBack.setFont(new Font("Sylfaen", Font.PLAIN, 22));
        btnBack.setBounds(103, 440, 113, 36);
        contentPane.add(btnBack);

        btnSubmit = new JButton("SUBMIT");
        btnSubmit.setFont(new Font("Sylfaen", Font.PLAIN, 22));
        btnSubmit.addActionListener(new SignUpButtonListener());
        btnSubmit.setBounds(254, 440, 122, 36);
        contentPane.add(btnSubmit);

        JButton btnLogin = new JButton("LOGIN");
        btnLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                LoginGUI frame = new LoginGUI();
                frame.setVisible(true);
                dispose();
            }
        });
        btnLogin.setFont(new Font("Sylfaen", Font.PLAIN, 22));
        btnLogin.setBounds(412, 442, 107, 34);
        contentPane.add(btnLogin);

        JLabel lblNewLabel_3 = new JLabel("New label");
        lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
        lblNewLabel_3.setBounds(0, -22, 602, 530);
        contentPane.add(lblNewLabel_3);
    }

    private class SignUpButtonListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == btnSubmit) {
                String name = txtName.getText();
                String email = txtEmail.getText();
                String password = txtPassword.getText();
                String phone = txtPhone.getText();

                if (isValidInput(name, email, password, phone)) {
                    Customer customer = new Customer(name, email, password, phone);
                    CustomerController customerController = new CustomerController();

                    try {
                        int success = customerController.insertCustomer(customer);

                        if (success > 0) {
                            JOptionPane.showMessageDialog(btnSubmit, "Sign Up Successful!", "Success",
                                    JOptionPane.INFORMATION_MESSAGE);
                            clearForm();
                        } else {
                            JOptionPane.showMessageDialog(btnSubmit, "Sign Up Failed!", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (Exception ex) {
                        ex.printStackTrace();
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                JOptionPane.showMessageDialog(btnSubmit, "Error: " + ex.getMessage(), "Error",
                                        JOptionPane.ERROR_MESSAGE);
                            }
                        });
                    }
                }
            }
        }
    }

    private boolean isValidInput(String name, String email, String password, String phone) {
        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(btnSubmit, "Invalid Email Address", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return isValidPassword(password);
    }

    private void clearForm() {
        txtName.setText("");
        txtEmail.setText("");
        txtPassword.setText("");
        txtPhone.setText("");
    }

    private boolean isValidEmail(String email) {
        return email.matches(".+@.+\\..+");
    }

    private boolean isValidPassword(String password) {
        if (password.length() >= 6) {
            return true;
        } else {
            JOptionPane.showMessageDialog(btnSubmit, "Password must be at least 6 characters long.", "Error",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}
