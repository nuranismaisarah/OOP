package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.Generate_PDF;
import controller.TicketController;
import model.Ticket;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;

public class Ticket_page4 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtAdult;
	private JTextField txtSenior;
	private JTextField txtChildren;
	private JTextField txtDate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args,int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ticket_page4 frame = new Ticket_page4(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ticket_page4(int customerID) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblRm_2_1 = new JLabel("RM 35 / PERSON");
		lblRm_2_1.setVerticalAlignment(SwingConstants.TOP);
		lblRm_2_1.setOpaque(true);
		lblRm_2_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblRm_2_1.setForeground(Color.BLACK);
		lblRm_2_1.setFont(new Font("Sylfaen", Font.PLAIN, 20));
		lblRm_2_1.setBackground(new Color(255, 255, 128));
		lblRm_2_1.setBounds(220, 261, 172, 31);
		contentPane.add(lblRm_2_1);
		
		JLabel lblRm_2 = new JLabel("RM 30 / PERSON");
		lblRm_2.setVerticalAlignment(SwingConstants.TOP);
		lblRm_2.setOpaque(true);
		lblRm_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblRm_2.setForeground(Color.BLACK);
		lblRm_2.setFont(new Font("Sylfaen", Font.PLAIN, 20));
		lblRm_2.setBackground(new Color(255, 255, 128));
		lblRm_2.setBounds(219, 204, 172, 31);
		contentPane.add(lblRm_2);
		
		JLabel lblRm = new JLabel("RM 45 / PERSON");
		lblRm.setHorizontalAlignment(SwingConstants.CENTER);
		lblRm.setVerticalAlignment(SwingConstants.TOP);
		lblRm.setOpaque(true);
		lblRm.setForeground(Color.BLACK);
		lblRm.setFont(new Font("Sylfaen", Font.PLAIN, 20));
		lblRm.setBackground(new Color(255, 255, 128));
		lblRm.setBounds(220, 148, 172, 31);
		contentPane.add(lblRm);
		
		JLabel TOTAL = new JLabel("TOTAL");
		TOTAL.setVerticalAlignment(SwingConstants.TOP);
		TOTAL.setOpaque(true);
		TOTAL.setHorizontalAlignment(SwingConstants.CENTER);
		TOTAL.setFont(new Font("Sylfaen", Font.PLAIN, 25));
		TOTAL.setBackground(new Color(255, 168, 211));
		TOTAL.setBounds(9, 315, 201, 31);
		contentPane.add(TOTAL);
		
		JTextArea textPrintTotal = new JTextArea();
		textPrintTotal.setFont(new Font("Sylfaen", Font.PLAIN, 26));
		textPrintTotal.setBounds(409, 309, 124, 40);
		textPrintTotal.setEditable(false);
		contentPane.add(textPrintTotal);
		
		
		txtDate = new JTextField();
		txtDate.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtDate.setBounds(370, 393, 163, 31);
		contentPane.add(txtDate);
		txtDate.setColumns(10);
		
		JLabel lblDate = new JLabel(" DATE (YYYY-MM-DD)");
		lblDate.setVerticalAlignment(SwingConstants.TOP);
		lblDate.setOpaque(true);
		lblDate.setBackground(new Color(255, 255, 128));
		lblDate.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblDate.setBounds(126, 402, 234, 22);
		contentPane.add(lblDate);
		
		JLabel lblNewLabel = new JLabel("AQUARIA MELAKA TICKET");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(255, 255, 128));
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 40));
		lblNewLabel.setBounds(20, 20, 534, 31);
		contentPane.add(lblNewLabel);
		
		JLabel lblTicketMustBe = new JLabel("Ticket must be purchase one day before !!!");
		lblTicketMustBe.setVerticalAlignment(SwingConstants.TOP);
		lblTicketMustBe.setOpaque(true);
		lblTicketMustBe.setFont(new Font("Sylfaen", Font.BOLD, 25));
		lblTicketMustBe.setBackground(new Color(255, 255, 128));
		lblTicketMustBe.setBounds(62, 356, 471, 31);
		contentPane.add(lblTicketMustBe);
		
		JLabel lblCategory = new JLabel("CATEGORY");
		lblCategory.setVerticalAlignment(SwingConstants.TOP);
		lblCategory.setOpaque(true);
		lblCategory.setBackground(new Color(255, 255, 128));
		lblCategory.setForeground(new Color(0, 0, 0));
		lblCategory.setFont(new Font("Sylfaen", Font.BOLD, 29));
		lblCategory.setBounds(30, 88, 172, 31);
		contentPane.add(lblCategory);
		
		JLabel lblQuantity = new JLabel("QUANTITY");
		lblQuantity.setVerticalAlignment(SwingConstants.TOP);
		lblQuantity.setOpaque(true);
		lblQuantity.setBackground(new Color(255, 255, 128));
		lblQuantity.setFont(new Font("Sylfaen", Font.BOLD, 29));
		lblQuantity.setBounds(391, 88, 163, 31);
		contentPane.add(lblQuantity);
		
		JLabel lblAdult = new JLabel("ADULT");
		lblAdult.setHorizontalAlignment(SwingConstants.CENTER);
		lblAdult.setVerticalAlignment(SwingConstants.TOP);
		lblAdult.setBackground(new Color(255, 168, 211));
		lblAdult.setOpaque(true);
		lblAdult.setFont(new Font("Sylfaen", Font.PLAIN, 25));
		lblAdult.setBounds(9, 148, 201, 31);
		contentPane.add(lblAdult);
		
		JLabel lblSeniorCitizen = new JLabel("SENIOR CITIZEN");
		lblSeniorCitizen.setHorizontalAlignment(SwingConstants.CENTER);
		lblSeniorCitizen.setVerticalAlignment(SwingConstants.TOP);
		lblSeniorCitizen.setBackground(new Color(255, 168, 211));
		lblSeniorCitizen.setOpaque(true);
		lblSeniorCitizen.setFont(new Font("Sylfaen", Font.PLAIN, 25));
		lblSeniorCitizen.setBounds(9, 204, 200, 31);
		contentPane.add(lblSeniorCitizen);
		
		JLabel lblChild = new JLabel("CHILD");
		lblChild.setHorizontalAlignment(SwingConstants.CENTER);
		lblChild.setVerticalAlignment(SwingConstants.TOP);
		lblChild.setBackground(new Color(255, 168, 211));
		lblChild.setOpaque(true);
		lblChild.setFont(new Font("Sylfaen", Font.PLAIN, 25));
		lblChild.setBounds(9, 261, 201, 31);
		contentPane.add(lblChild);
		
		JButton btnNext = new JButton("DONE");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    if (txtAdult.getText().isEmpty() && txtSenior.getText().isEmpty() && txtChildren.getText().isEmpty()) {
			        JOptionPane.showMessageDialog(btnNext, "You need to purchase at least one ticket!");
			    } else {
			        if (txtDate.getText().isEmpty()) {
			            JOptionPane.showMessageDialog(btnNext, "Choose a date!");
			        } else {
			            // Regular expression for the "YYYY-MM-DD" format
			            String dateFormatRegex = "\\d{4}-\\d{2}-\\d{2}";

			            // Validate the entered date using the regular expression
			            if (!Pattern.matches(dateFormatRegex, txtDate.getText())) {
			                JOptionPane.showMessageDialog(btnNext, "Please enter a valid date in the format YYYY-MM-DD!");
			            } else {
			                // Parse the entered date
			                LocalDate enteredDate = LocalDate.parse(txtDate.getText());

			                // Check if the entered date is today
			                if (enteredDate.isEqual(LocalDate.now())) {
			                    JOptionPane.showMessageDialog(btnNext, "Please choose a date one day before!");
			                } else if (enteredDate.isBefore(LocalDate.now())) {
			                    JOptionPane.showMessageDialog(btnNext, "Please enter a date in the future!");
			                } else {
			                    // The date is valid and not today, you can proceed with creating the Ticket object and setting values
			                    TicketController ticketController = new TicketController();
			                    Ticket ticket = new Ticket();

			                    int adult = txtAdult.getText().isEmpty() ? 0 : Integer.parseInt(txtAdult.getText());
			                    int senior = txtSenior.getText().isEmpty() ? 0 : Integer.parseInt(txtSenior.getText());
			                    int children = txtChildren.getText().isEmpty() ? 0 : Integer.parseInt(txtChildren.getText());


			                 // Calculate total
		                        int adultPrice = 45;
		                        int childPrice = 35;
		                        int seniorPrice = 30;
		                        int total = (adult * adultPrice) + (children * childPrice) + (senior * seniorPrice);
		                        
		                        ticket.setAdult(adult);
		                        ticket.setSenior(senior);
			                    ticket.setChildren(children);
			                    ticket.setAmount(total);
			                    ticket.setDate(txtDate.getText());
			                    ticket.setCustomerID(customerID);

		                        // Insert total into the JTextArea
		                        textPrintTotal.setText("RM " + total);

			                    try {
			                        ticketController.insertTicket(ticket);
			                        JOptionPane.showMessageDialog(btnNext, "Ticket Purchase Success!");
			                    } catch (ClassNotFoundException | SQLException e1) {
			                        e1.printStackTrace();
			                    }
			                }
			            }
			        }
			    }
			}
		});
		btnNext.setVerticalAlignment(SwingConstants.TOP);
		btnNext.setBackground(new Color(255, 255, 255));
		btnNext.setFont(new Font("Sylfaen", Font.BOLD, 22));
		btnNext.setBounds(457, 443, 107, 31);
		contentPane.add(btnNext);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setVerticalAlignment(SwingConstants.TOP);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TicketPage frame = new TicketPage(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnBack.setBackground(new Color(255, 255, 255));
		btnBack.setFont(new Font("Sylfaen", Font.BOLD, 22));
		btnBack.setBounds(26, 443, 107, 31);
		contentPane.add(btnBack);
		
		txtAdult = new JTextField();
		txtAdult.setHorizontalAlignment(SwingConstants.CENTER);
		txtAdult.setFont(new Font("Sylfaen", Font.PLAIN, 27));
		txtAdult.setBounds(409, 145, 124, 39);
		contentPane.add(txtAdult);
		txtAdult.setColumns(10);
		
		txtSenior = new JTextField();
		txtSenior.setHorizontalAlignment(SwingConstants.CENTER);
		txtSenior.setFont(new Font("Sylfaen", Font.PLAIN, 27));
		txtSenior.setBounds(409, 199, 124, 44);
		contentPane.add(txtSenior);
		txtSenior.setColumns(10);
		
		txtChildren = new JTextField();
		txtChildren.setHorizontalAlignment(SwingConstants.CENTER);
		txtChildren.setFont(new Font("Sylfaen", Font.PLAIN, 27));
		txtChildren.setBounds(409, 257, 124, 42);
		contentPane.add(txtChildren);
		txtChildren.setColumns(10);
		
		JButton btnPrint = new JButton("PRINT");
		btnPrint.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        try {
		            Ticket ticket = new Ticket();
		            TicketController ticketController = new TicketController();


                    int adult = txtAdult.getText().isEmpty() ? 0 : Integer.parseInt(txtAdult.getText());
                    int senior = txtSenior.getText().isEmpty() ? 0 : Integer.parseInt(txtSenior.getText());
                    int children = txtChildren.getText().isEmpty() ? 0 : Integer.parseInt(txtChildren.getText());


                 // Calculate total
                    int adultPrice = 45;
                    int childPrice = 35;
                    int seniorPrice = 30;
                    int total = (adult * adultPrice) + (children * childPrice) + (senior * seniorPrice);
                    
                    ticket.setAdult(adult);
                    ticket.setSenior(senior);
                    ticket.setChildren(children);
                    ticket.setAmount(total);
                    ticket.setDate(txtDate.getText());
                    ticket.setCustomerID(customerID);

                    String file_name = "C:\\Users\\USER\\Desktop\\Generate_PDF\\Ticketaquaria";
		            Generate_PDF.generateReceipt(file_name, ticket);
		            
		            System.out.println("Printed receipt successfully");
		        } catch (Exception ex) {
		            System.err.println("Error printing receipt: " + ex.getMessage());
		        }
		    }
		});
		
		btnPrint.setVerticalAlignment(SwingConstants.TOP);
		btnPrint.setFont(new Font("Sylfaen", Font.BOLD, 22));
		btnPrint.setBounds(319, 443, 112, 31);
		contentPane.add(btnPrint);
		
		JButton btnClear = new JButton("CLEAR");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ticket_page4 frame = new Ticket_page4(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnClear.setVerticalAlignment(SwingConstants.TOP);
		btnClear.setFont(new Font("Sylfaen", Font.BOLD, 22));
		btnClear.setBounds(171, 443, 107, 31);
		contentPane.add(btnClear);
		
		JLabel Total = new JLabel("New label");
		Total.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		Total.setBounds(0, -25, 592, 523);
		contentPane.add(Total);
	}
}
