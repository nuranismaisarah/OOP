package view;


import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

import java.util.List;
import java.sql.SQLException;
import controller.TicketController;
import model.Ticket;
import javax.swing.ImageIcon;


public class GeneratePieChart extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtYEAR;
	private JTextField txtMONTH;
	private TicketController ticketController;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args,int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GeneratePieChart frame = new GeneratePieChart(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GeneratePieChart(int customerID) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("TICKET POPULARITY PIE CHART");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(255, 255, 128));
		lblNewLabel.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblNewLabel.setBounds(127, 39, 350, 66);
		contentPane.add(lblNewLabel);
		
		JLabel lblYear = new JLabel("YEAR :");
		lblYear.setOpaque(true);
		lblYear.setBackground(new Color(255, 255, 128));
		lblYear.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblYear.setBounds(59, 192, 87, 38);
		contentPane.add(lblYear);
		
		JLabel lblNewLabel_1 = new JLabel("MONTH : ");
		lblNewLabel_1.setOpaque(true);
		lblNewLabel_1.setBackground(new Color(255, 255, 128));
		lblNewLabel_1.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblNewLabel_1.setBounds(287, 192, 104, 38);
		contentPane.add(lblNewLabel_1);
		
		txtYEAR = new JTextField();
		txtYEAR.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtYEAR.setBounds(156, 190, 104, 38);
		contentPane.add(txtYEAR);
		txtYEAR.setColumns(10);
		
		txtMONTH = new JTextField();
		txtMONTH.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtMONTH.setBounds(401, 191, 118, 38);
		contentPane.add(txtMONTH);
		txtMONTH.setColumns(10);
		
		JButton btnViewPie = new JButton("VIEW PIE CHART");
		btnViewPie.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				generateChart();
			}
		});
		btnViewPie.setFont(new Font("Sylfaen", Font.PLAIN, 18));
		btnViewPie.setBounds(112, 321, 184, 46);
		contentPane.add(btnViewPie);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TicketPage frame = new TicketPage(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		
		btnBack.setFont(new Font("Sylfaen", Font.PLAIN, 18));
		btnBack.setBounds(326, 321, 155, 46);
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		lblNewLabel_2.setBounds(0, 0, 602, 508);
		contentPane.add(lblNewLabel_2);
		
		 ticketController = new TicketController();

	        
	}
	
	 private void generateChart() {
	        String yearStr = txtYEAR.getText();
	        String monthStr = txtMONTH.getText();

	        if (isValidInput(yearStr, monthStr)) {
	            int year = Integer.parseInt(yearStr);
	            int month = Integer.parseInt(monthStr);

	            try {
	                if (ticketController == null) {
	                    ticketController = new TicketController();
	                }

	                List<Ticket> ticketData = ticketController.getTicketData(year, month);

	                DefaultPieDataset dataset = new DefaultPieDataset();
	                for (Ticket ticket : ticketData) {
	                    dataset.setValue("Adult", ticket.getAdult());
	                    dataset.setValue("Senior Citizen", ticket.getSenior());
	                    dataset.setValue("Children", ticket.getChildren());
	                }

	                JFreeChart chart = ChartFactory.createPieChart(
	                        "Ticket Popularity Pie Chart",
	                        dataset,
	                        true,
	                        true,
	                        false);

	                PiePlot plot = (PiePlot) chart.getPlot();
	                plot.setSectionPaint("Senior Citizen", new Color(0, 255, 0));       
	                plot.setSectionPaint("Children", new Color(0, 0, 255));            

	               
	                JFrame frame = new JFrame("Pie Chart");
	                frame.setSize(800, 600);
	                frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	                ChartPanel chartPanel = new ChartPanel(chart);
	                frame.setContentPane(chartPanel);
	                frame.setVisible(true);

	            } catch (ClassNotFoundException | SQLException e) {
	                e.printStackTrace();
	                // Handle exceptions
	            }
	        }
	    }

	    private boolean isValidInput(String yearStr, String monthStr) {
	        
	        if (yearStr.isEmpty() || monthStr.isEmpty()) {
	            JOptionPane.showMessageDialog(this, "Please enter both year and month.", "Input Error", JOptionPane.ERROR_MESSAGE);
	            return false;
	        }

	        try {
	            int year = Integer.parseInt(yearStr);
	            int month = Integer.parseInt(monthStr);

	            if (year < 0 || month < 1 || month > 12) {
	          
	                JOptionPane.showMessageDialog(this, "Invalid year or month.", "Input Error", JOptionPane.ERROR_MESSAGE);
	                return false;
	            }
	            
	            return true;
	        } catch (NumberFormatException e) {
	        
	            JOptionPane.showMessageDialog(this, "Please enter valid numeric values for year and month.", "Input Error", JOptionPane.ERROR_MESSAGE);
	            return false;
	        }
	    }
}
