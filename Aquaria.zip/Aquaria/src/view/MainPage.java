package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class MainPage extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainPage frame = new MainPage();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MainPage() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblWelcome = new JLabel("WELCOME TO AQUARIA MELAKA");
		lblWelcome.setBackground(new Color(255, 255, 128));
		lblWelcome.setOpaque(true);
		lblWelcome.setVerticalAlignment(SwingConstants.TOP);
		lblWelcome.setFont(new Font("Sylfaen", Font.PLAIN, 28));
		lblWelcome.setBounds(80, 26, 450, 27);
		contentPane.add(lblWelcome);
		
		JLabel lblOpenHours = new JLabel("OPENING HOURS !");
		lblOpenHours.setVerticalAlignment(SwingConstants.TOP);
		lblOpenHours.setBackground(new Color(255, 255, 255));
		lblOpenHours.setOpaque(true);
		lblOpenHours.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblOpenHours.setBounds(202, 78, 204, 27);
		contentPane.add(lblOpenHours);
		
		JLabel lblWeekdaysOpenAt = new JLabel("WEEKDAYS AT 9:00 AM");
		lblWeekdaysOpenAt.setVerticalAlignment(SwingConstants.TOP);
		lblWeekdaysOpenAt.setOpaque(true);
		lblWeekdaysOpenAt.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblWeekdaysOpenAt.setBackground(new Color(255, 255, 255));
		lblWeekdaysOpenAt.setBounds(308, 134, 253, 27);
		contentPane.add(lblWeekdaysOpenAt);
		
		JLabel lblWeekendAt = new JLabel("WEEKEND AT 8:30 AM");
		lblWeekendAt.setVerticalAlignment(SwingConstants.TOP);
		lblWeekendAt.setOpaque(true);
		lblWeekendAt.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblWeekendAt.setBackground(new Color(255, 255, 255));
		lblWeekendAt.setBounds(40, 134, 236, 27);
		contentPane.add(lblWeekendAt);
		
		JLabel lblClosed = new JLabel("CLOSED AT 6:00 PM");
		lblClosed.setVerticalAlignment(SwingConstants.TOP);
		lblClosed.setOpaque(true);
		lblClosed.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblClosed.setBackground(new Color(255, 255, 255));
		lblClosed.setBounds(193, 194, 213, 27);
		contentPane.add(lblClosed);
		
		JLabel lblAge = new JLabel("AGE");
		lblAge.setVerticalAlignment(SwingConstants.TOP);
		lblAge.setOpaque(true);
		lblAge.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblAge.setBackground(new Color(255, 255, 255));
		lblAge.setBounds(119, 242, 54, 27);
		contentPane.add(lblAge);
		
		JLabel lblAge_2 = new JLabel("<html>3-12 <br>13-52<br>53 and above");
		lblAge_2.setVerticalAlignment(SwingConstants.TOP);
		lblAge_2.setOpaque(true);
		lblAge_2.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblAge_2.setBackground(new Color(255, 255, 255));
		lblAge_2.setBounds(87, 284, 122, 90);
		contentPane.add(lblAge_2);
		
		JLabel lblPrice = new JLabel("PRICE");
		lblPrice.setVerticalAlignment(SwingConstants.TOP);
		lblPrice.setOpaque(true);
		lblPrice.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblPrice.setBackground(new Color(255, 255, 255));
		lblPrice.setBounds(433, 245, 72, 27);
		contentPane.add(lblPrice);
		
		JLabel lblAge_2_1 = new JLabel("<html>RM 35 <br>RM 45<br>RM 30");
		lblAge_2_1.setVerticalAlignment(SwingConstants.TOP);
		lblAge_2_1.setOpaque(true);
		lblAge_2_1.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblAge_2_1.setBackground(new Color(255, 255, 255));
		lblAge_2_1.setBounds(433, 285, 72, 90);
		contentPane.add(lblAge_2_1);

        setVisible(true);
		JButton btnLogIn = new JButton("LOG IN");
		btnLogIn.setBackground(new Color(255, 255, 255));
		btnLogIn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LoginGUI frame = new LoginGUI();
				frame.setVisible(true);
				dispose();
			}
		});
		
		JLabel lblPrice_1 = new JLabel("");
		lblPrice_1.setVerticalAlignment(SwingConstants.TOP);
		lblPrice_1.setOpaque(true);
		lblPrice_1.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		lblPrice_1.setBackground(new Color(255, 255, 128));
		lblPrice_1.setBounds(40, 63, 521, 335);
		contentPane.add(lblPrice_1);
		btnLogIn.setBounds(93, 417, 153, 37);
		btnLogIn.setFont(new Font("Rockwell", Font.PLAIN, 23));
		contentPane.add(btnLogIn);

        setVisible(true);
		JButton btnSignUp = new JButton("SIGN UP");
		btnSignUp.setBackground(new Color(255, 255, 255));
		btnSignUp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				SignUpGuiPage frame = new SignUpGuiPage();
				frame.setVisible(true);
				dispose();
			}
		});
		btnSignUp.setBounds(353, 417, 152, 37);
		btnSignUp.setFont(new Font("Rockwell", Font.PLAIN, 23));
		contentPane.add(btnSignUp);
		
        setVisible(true);
		JLabel lblBackground = new JLabel("New label");
		lblBackground.setBackground(new Color(0, 0, 0));
		lblBackground.setBounds(0, 0, 588, 491);
		lblBackground.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		contentPane.add(lblBackground);
	}
}
