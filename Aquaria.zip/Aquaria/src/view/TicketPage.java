package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.Color;

public class TicketPage extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args,int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TicketPage frame = new TicketPage(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TicketPage(int customerID) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		
		JButton btnView = new JButton("VIEW TICKET");
		btnView.setBounds(152, 76, 245, 54);
		btnView.setFont(new Font("Sylfaen", Font.PLAIN, 24));
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewTicket frame = new ViewTicket(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		contentPane.setLayout(null);
		
		JLabel lblTicketMenu = new JLabel("TICKET MENU");
		lblTicketMenu.setVerticalAlignment(SwingConstants.TOP);
		lblTicketMenu.setHorizontalAlignment(SwingConstants.CENTER);
		lblTicketMenu.setBounds(152, 19, 245, 39);
		lblTicketMenu.setBackground(new Color(255, 255, 128));
		lblTicketMenu.setOpaque(true);
		lblTicketMenu.setFont(new Font("Sylfaen", Font.PLAIN, 35));
		contentPane.add(lblTicketMenu);
		contentPane.add(btnView);
		
		JButton btnAddTicket = new JButton("ADD TICKET");
		btnAddTicket.setBounds(152, 236, 245, 57);
		btnAddTicket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Ticket_page4 frame = new Ticket_page4(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnAddTicket.setFont(new Font("Sylfaen", Font.PLAIN, 24));
		contentPane.add(btnAddTicket);
		
		JButton btnDeleteTicket = new JButton("DELETE TICKET");
		btnDeleteTicket.setBounds(152, 320, 245, 57);
		btnDeleteTicket.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DelTicketPage frame = new DelTicketPage(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnDeleteTicket.setFont(new Font("Sylfaen", Font.PLAIN, 24));
		contentPane.add(btnDeleteTicket);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setBounds(152, 409, 245, 57);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				CustAcc frame = new CustAcc(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnBack.setFont(new Font("Sylfaen", Font.PLAIN, 24));
		contentPane.add(btnBack);
		
		JButton btnNewButton = new JButton("TICKETS ANALYSIS");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GeneratePieChart frame = new GeneratePieChart(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setFont(new Font("Sylfaen", Font.PLAIN, 23));
		btnNewButton.setBounds(152, 156, 245, 57);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setBounds(0, 0, 592, 498);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		contentPane.add(lblNewLabel);
	}
}
