package view;
import java.sql.SQLException;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.List;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JLabel;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import controller.TicketController;
import model.Ticket;

public class ViewTicket extends JFrame {

	private static final long serialVersionUID = 1L;
	protected static final String Date = null;
	private JPanel contentPane;
	private JTable tableTicket;
	private JTextField txtSearchDate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args,int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewTicket frame = new ViewTicket(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewTicket(int customerID) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(139, 134, 355, 243);
		scrollPane.setFont(new Font("Sylfaen", Font.PLAIN, 30));
		contentPane.add(scrollPane);
		
		tableTicket = new JTable();
		tableTicket.setModel(new DefaultTableModel(
			new Object[][]
			{},
			new String[] 
			{
				"Ticket ID", "Adult", "Senior", "Children", "Amount", "Date"
			}
		)
		{
		    /**
			 * 
			 */
			private static final long serialVersionUID = 1L;

			public boolean isCellEditable(int row, int column) {                
		                return false;               
		        }
		});
		tableTicket.getColumnModel().getColumn(0).setPreferredWidth(55);
		tableTicket.getColumnModel().getColumn(0).setMinWidth(55);
		tableTicket.getColumnModel().getColumn(0).setMaxWidth(55);
		
		tableTicket.getColumnModel().getColumn(1).setPreferredWidth(50);
		tableTicket.getColumnModel().getColumn(1).setMinWidth(50);
		tableTicket.getColumnModel().getColumn(1).setMaxWidth(50);
		
		tableTicket.getColumnModel().getColumn(2).setPreferredWidth(50);
		tableTicket.getColumnModel().getColumn(2).setMinWidth(50);
		tableTicket.getColumnModel().getColumn(2).setMaxWidth(50);
		
		tableTicket.getColumnModel().getColumn(3).setPreferredWidth(55);
		tableTicket.getColumnModel().getColumn(3).setMinWidth(55);
		tableTicket.getColumnModel().getColumn(3).setMaxWidth(55);
		
		tableTicket.getColumnModel().getColumn(4).setPreferredWidth(55);
		tableTicket.getColumnModel().getColumn(4).setMinWidth(55);
		tableTicket.getColumnModel().getColumn(4).setMaxWidth(55);
		
		tableTicket.getColumnModel().getColumn(5).setPreferredWidth(90);
		tableTicket.getColumnModel().getColumn(5).setMinWidth(90);
		tableTicket.getColumnModel().getColumn(5).setMaxWidth(90);
		
		scrollPane.setViewportView(tableTicket);
		
		TicketController ticketController = new TicketController();
		DefaultTableModel model = (DefaultTableModel) tableTicket.getModel();
		
		try {
			List<Ticket> tickets = ticketController.viewTicket(customerID);
			
			for (Ticket ticket : tickets) {
                Object[] row = { ticket.getTicketID(),ticket.getAdult(),ticket.getSenior(),ticket.getChildren(),ticket.getAmount(),ticket.getDate()};
                model.addRow(row);
            }
			
		} catch (ClassNotFoundException | SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		JButton btnSearch = new JButton("SEARCH");
		btnSearch.setBounds(426, 76, 141, 34);
		btnSearch.setVerticalAlignment(SwingConstants.TOP);
		btnSearch.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		btnSearch.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				model.setRowCount(0);
				String date = txtSearchDate.getText();
				
				TicketController ticketController = new TicketController();
				DefaultTableModel model = (DefaultTableModel) tableTicket.getModel();
				
				try {
					List<Ticket> tickets = ticketController.searchTicket(customerID,date);
					
					for (Ticket ticket : tickets) {
		                Object[] row = { ticket.getTicketID(),ticket.getAdult(),ticket.getSenior(),ticket.getChildren(),ticket.getAmount(),ticket.getDate()};
		                model.addRow(row);
		            }
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
				
				}
		});
		
		JLabel lblViewTicket = new JLabel("VIEW TICKETS");
		lblViewTicket.setBounds(199, 10, 200, 34);
		lblViewTicket.setBackground(new Color(255, 255, 128));
		lblViewTicket.setOpaque(true);;
		
		
		JLabel lblSearch = new JLabel("<html>SEARCH BY DATE :<br>(YYYY-MM-DD)</html>");
		lblSearch.setBounds(10, 62, 182, 54);
		lblSearch.setOpaque(true);
		lblSearch.setBackground(new Color(255, 255, 128));
		lblSearch.setVerticalAlignment(SwingConstants.TOP);
		lblSearch.setFont(new Font("Sylfaen", Font.PLAIN, 20));
		contentPane.add(lblSearch);
		lblViewTicket.setVerticalAlignment(SwingConstants.TOP);
		lblViewTicket.setFont(new Font("Sylfaen", Font.PLAIN, 28));
		contentPane.add(lblViewTicket);
		
		JButton btnBack = new JButton("BACK");
		btnBack.setBounds(139, 431, 108, 34);
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				TicketPage frame = new TicketPage(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnBack.setVerticalAlignment(SwingConstants.TOP);
		btnBack.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		contentPane.add(btnBack);
		contentPane.add(btnSearch);
		
		txtSearchDate = new JTextField();
		txtSearchDate.setBounds(199, 76, 212, 34);
		txtSearchDate.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		contentPane.add(txtSearchDate);
		txtSearchDate.setColumns(10);
		
		JButton btnviewAll = new JButton("VIEW ALL");
		btnviewAll.setBounds(364, 431, 141, 34);
		btnviewAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				model.setRowCount(0);
				TicketController ticketController = new TicketController();
				DefaultTableModel model = (DefaultTableModel) tableTicket.getModel();
				
				try {
					List<Ticket> tickets = ticketController.viewTicket(customerID);
					
					for (Ticket ticket : tickets) {
		                Object[] row = { ticket.getTicketID(),ticket.getAdult(),ticket.getSenior(),ticket.getChildren(),ticket.getAmount(),ticket.getDate()};
		                model.addRow(row);
		            }
					
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnviewAll.setVerticalAlignment(SwingConstants.TOP);
		btnviewAll.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		contentPane.add(btnviewAll);
		
		JLabel lblbackground = new JLabel("New label");
		lblbackground.setBounds(0, 0, 592, 507);
		lblbackground.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		contentPane.add(lblbackground);
		
		
	}
}
