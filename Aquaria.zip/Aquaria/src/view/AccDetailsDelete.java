package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.CustomerController;

import javax.swing.JLabel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.ImageIcon;

public class AccDetailsDelete extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args, int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccDetailsDelete frame = new AccDetailsDelete(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AccDetailsDelete(int customerID) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Are you sure you want to delete your account?");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(255, 87, 87));
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 25));
		lblNewLabel.setBounds(35, 173, 520, 44);
		contentPane.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("SURE");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setFont(new Font("Sylfaen", Font.BOLD, 21));
		btnNewButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        
		        	
		        	CustomerController customerController = new CustomerController();
		            // Assuming you have access to the customerID within the context
		         // Replace this with the method to get the current customerID

		            // Call the deleteCustomer function
		            int deletionResult=0;
					try {
						deletionResult = customerController.deleteCustomer(customerID);
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}

		            if (deletionResult > 0) {
		                // Deletion was successful
		                System.out.println("Customer deleted successfully!");
		            } else {
		                // Deletion failed
		                System.out.println("Failed to delete customer.");
		            }

		            // Open the MainPage
		            MainPage frame = new MainPage();
		            frame.setVisible(true);
		            dispose();
		       
		    }
		});

		
		
		btnNewButton.setBounds(385, 331, 129, 44);
		contentPane.add(btnNewButton);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AccDetailUpdate frame = new AccDetailUpdate(customerID);
				frame.setVisible(true);
				dispose();
			}
		});
		btnBack.setFont(new Font("Sylfaen", Font.BOLD, 21));
		btnBack.setBounds(97, 331, 129, 44);
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		lblNewLabel_1.setBounds(0, 0, 592, 498);
		contentPane.add(lblNewLabel_1);
	}

}
