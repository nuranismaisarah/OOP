package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.CustomerController;
import model.Customer;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;

public class AccDetailsUpdate2 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtEmail;
	private JTextField txtPassword;
	private JTextField txtPhone;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args, int customerID) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccDetailsUpdate2 frame = new AccDetailsUpdate2(customerID);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AccDetailsUpdate2(int customerID) {
		CustomerController customerController = new CustomerController();
		Customer customer = new Customer();
		try {
			customer = customerController.selectCustomer(customerID);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 606, 535);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("UPDATE ACCOUNT DETAIL");
		lblNewLabel.setOpaque(true);
		lblNewLabel.setBackground(new Color(255, 255, 128));
		lblNewLabel.setFont(new Font("Sylfaen", Font.BOLD, 32));
		lblNewLabel.setBounds(56, 29, 469, 70);
		contentPane.add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("NAME :");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_2.setOpaque(true);
		lblNewLabel_2.setFont(new Font("Sylfaen", Font.BOLD, 22));
		lblNewLabel_2.setBackground(new Color(255, 255, 128));
		lblNewLabel_2.setBounds(97, 146, 92, 26);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("EMAIL :");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setBackground(new Color(255, 255, 128));
		lblNewLabel_3.setOpaque(true);
		lblNewLabel_3.setFont(new Font("Sylfaen", Font.BOLD, 22));
		lblNewLabel_3.setBounds(97, 207, 92, 30);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("PASSWORD :");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_4.setBackground(new Color(255, 255, 128));
		lblNewLabel_4.setOpaque(true);
		lblNewLabel_4.setFont(new Font("Sylfaen", Font.BOLD, 22));
		lblNewLabel_4.setBounds(63, 259, 151, 26);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("PHONE NUMBER :");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel_5.setBackground(new Color(255, 255, 128));
		lblNewLabel_5.setOpaque(true);
		lblNewLabel_5.setFont(new Font("Sylfaen", Font.BOLD, 22));
		lblNewLabel_5.setBounds(45, 315, 203, 26);
		contentPane.add(lblNewLabel_5);
		
		txtName = new JTextField();
		txtName.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtName.setBounds(287, 146, 222, 30);
		contentPane.add(txtName);
		txtName.setColumns(10);
		txtName.setText(customer.getName());
		
		txtEmail = new JTextField();
		txtEmail.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtEmail.setBounds(287, 207, 222, 30);
		contentPane.add(txtEmail);
		txtEmail.setColumns(10);
		txtEmail.setText(customer.getEmail());
		
		txtPassword = new JTextField();
		txtPassword.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtPassword.setBounds(287, 258, 222, 30);
		contentPane.add(txtPassword);
		txtPassword.setColumns(10);
		txtPassword.setText(customer.getPassword());
		
		txtPhone = new JTextField();
		txtPhone.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		txtPhone.setBounds(287, 315, 222, 30);
		contentPane.add(txtPhone);
		txtPhone.setColumns(10);
		txtPhone.setText(customer.getPhone());

		

		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Assuming you have a Customer object or relevant information for the update
		        Customer customerToUpdate = new Customer();

		        // Retrieve values from JTextFields
		        customerToUpdate.setName(txtName.getText());
		        customerToUpdate.setEmail(txtEmail.getText());
		        customerToUpdate.setPassword(txtPassword.getText());
		        customerToUpdate.setPhone(txtPhone.getText());
		        customerToUpdate.setCustomerID(customerID);

	
		        	CustomerController customerController = new CustomerController();
		            // Call the updateCustomer method
		            
					try {
						customerController.updateCustomer(customerToUpdate);
						JOptionPane.showMessageDialog(btnUpdate,"Details Updated!" );
						
					} catch (ClassNotFoundException | SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		       
		    }
		});


		btnUpdate.setFont(new Font("Sylfaen", Font.BOLD, 22));
		btnUpdate.setBounds(346, 397, 151, 48);
		contentPane.add(btnUpdate);
		
		JButton btnBack = new JButton("BACK");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AccDetailUpdate frame = new AccDetailUpdate(customerID);
				frame.setVisible(true);
				dispose();
			}
			
		});
		btnBack.setFont(new Font("Sylfaen", Font.PLAIN, 22));
		btnBack.setBounds(97, 397, 136, 48);
		contentPane.add(btnBack);
		
		JLabel lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.setIcon(new ImageIcon("C:\\Users\\USER\\eclipse-workspace\\Aquaria\\photo_2024-01-20_14-10-37.jpg"));
		lblNewLabel_6.setBounds(0, 0, 592, 498);
		contentPane.add(lblNewLabel_6);
	}
}
