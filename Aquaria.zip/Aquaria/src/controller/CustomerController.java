package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;



import database.MyDatabase;
import model.Customer;

public class CustomerController {

	public int doLogin(Customer customer)throws ClassNotFoundException, SQLException
	{
		int customerID = 0;
		Connection conn = MyDatabase.doConnection();
	
		String sql = "SELECT * FROM customer WHERE email = ? AND password = ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		
		preparedStatement.setString(1, customer.getEmail());
		preparedStatement.setString(2, customer.getPassword());
		
		ResultSet resultSet = preparedStatement.executeQuery();
		
		if (resultSet.next())
		{
			customerID = resultSet.getInt("customerID");
			customer.setCustomerID(customerID);
		}
		
		conn.close();
		return customerID;
		

	}

	public int insertCustomer(Customer customer) throws ClassNotFoundException, SQLException {
	      String sql = "INSERT INTO Customer (name, email, password, phone) VALUES (?, ?, ?, ?)";

	      Connection conn = MyDatabase.doConnection();
	      PreparedStatement preparedStatement = conn.prepareStatement(sql);

	      preparedStatement.setString(1, customer.getName());
	      preparedStatement.setString(2, customer.getEmail());
	      preparedStatement.setString(3, customer.getPassword());
	      preparedStatement.setString(4, customer.getPhone());

	      int success = preparedStatement.executeUpdate();

	      conn.close();

	      return success;
	  }
	
	public void updateCustomer(Customer customer) throws ClassNotFoundException, SQLException {
	    String sql = "UPDATE Customer SET name=?, email=?, password=?, phone=? WHERE customerID =?";

	    Connection conn = MyDatabase.doConnection();
	    PreparedStatement preparedStatement = conn.prepareStatement(sql);

	    preparedStatement.setString(1, customer.getName());
	    preparedStatement.setString(2, customer.getEmail());
	    preparedStatement.setString(3, customer.getPassword());
	    preparedStatement.setString(4, customer.getPhone());
	    preparedStatement.setInt(5, customer.getCustomerID());  // Assuming you have a customer_id field in your Customer class

	    preparedStatement.executeUpdate();

	    conn.close();

	
	}
	
	public int deleteCustomer(int customerID) throws ClassNotFoundException, SQLException {
	    String sql = "DELETE FROM Customer WHERE customerID=?";

	    Connection conn = MyDatabase.doConnection();
	    PreparedStatement preparedStatement = conn.prepareStatement(sql);
	    preparedStatement.setInt(1, customerID);

	    int success = preparedStatement.executeUpdate();

	    conn.close();

	    return success;
	}
	
	public Customer selectCustomer(int customerID)throws ClassNotFoundException, SQLException {
		
		Customer customer = new Customer();
		Connection conn = MyDatabase.doConnection();
		String sql = "SELECT * FROM customer WHERE customerID = ?";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		
		preparedStatement.setInt(1, customerID);
		
		
		ResultSet resultSet = preparedStatement.executeQuery();
		
		if (resultSet.next())
		{
			customer.setName(resultSet.getString("name"));
			customer.setEmail(resultSet.getString("email"));
			customer.setPassword(resultSet.getString("password"));
			customer.setPhone(resultSet.getString("phone"));

		}
		
		conn.close();
		return customer;
		
	}
}
