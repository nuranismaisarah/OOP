package controller;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import model.Ticket;

import java.io.FileOutputStream;

public class Generate_PDF {

    public static void generateReceipt(String filePath, Ticket ticket) {
        Document document = new Document();

        try {
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            document.add(new Paragraph(" "));
            
            // Add image at the top
            Image image = Image.getInstance("C:\\Users\\USER\\Desktop\\Generate_PDF\\photo_2024-01-26_18-38-04.jpg");
            image.scaleToFit(document.getPageSize().getWidth() - 20, 100);
            image.setAlignment(Element.ALIGN_CENTER);
            document.add(image);

            
            document.add(new Paragraph("-------------------------------------------------------------------------------------------------------------------------------"));
            document.add(new Paragraph(" "));

            // Add content to the PDF
            document.add(new Paragraph("Aquaria Melaka Ticket Receipt"));
            document.add(new Paragraph("Date: " + ticket.getDate()));
            
            document.add(new Paragraph(" "));
            // Create a table to display ticket details
            PdfPTable table = new PdfPTable(4); // Increase the column count to 4
            table.addCell("Category");
            table.addCell("Quantity");
            table.addCell("Unit Price");
            table.addCell("Total");

            table.addCell("Adult");
            table.addCell(Integer.toString(ticket.getAdult()));
            table.addCell("RM 45");
            table.addCell(String.format("RM %.2f", ticket.getAdult() * 45.0)); // Calculate total for adults

            table.addCell("Senior Citizen");
            table.addCell(Integer.toString(ticket.getSenior()));
            table.addCell("RM 30");
            table.addCell(String.format("RM %.2f", ticket.getSenior() * 30.0)); // Calculate total for seniors

            table.addCell("Children");
            table.addCell(Integer.toString(ticket.getChildren()));
            table.addCell("RM 35");
            table.addCell(String.format("RM %.2f", ticket.getChildren() * 35.0)); // Calculate total for children

            table.addCell("Total Amount");
            table.addCell(""); // Leave the "Quantity" column empty for the total row
            table.addCell(""); // Leave the "Unit Price" column empty for the total row
            table.addCell(String.format("RM %.2f", ticket.getAmount())); // Display the total

            document.add(table);

            document.close();
        } catch (DocumentException | java.io.IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        try {
            Ticket ticket = new Ticket();
            ticket.setDate("");
            ticket.setAdult(0);
            ticket.setSenior(0);
            ticket.setChildren(0);
            String file_name = "C:\\Users\\USER\\Desktop\\Generate_PDF\\TicketAquaria";
            generateReceipt(file_name, ticket);

            System.out.println("Successfully print !!");
        } catch (Exception e) {
            System.err.println(e);
        }
    }
}