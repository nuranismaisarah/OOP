package controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import database.MyDatabase;
import model.Ticket;

public class TicketController {

	
	public List<Ticket> viewTicket(int customerID) throws ClassNotFoundException, SQLException
	{
		
		 List<Ticket> tickets = new ArrayList<>();
		
		Connection conn = MyDatabase.doConnection();
		
		
		String sql = "SELECT * FROM ticket WHERE customerID = ?";
		PreparedStatement preparedStatement =  conn.prepareStatement(sql);
		preparedStatement.setInt(1, customerID);
		
		ResultSet resultSet = preparedStatement.executeQuery();
	
		while (resultSet.next()) 
		{
            int ticketID = resultSet.getInt("ticketID");
            int adult = resultSet.getInt("AdultQuantity");
            int senior = resultSet.getInt("SeniorCitizenQuantity");
            int children = resultSet.getInt("ChildrenQuantity");
            double amount = resultSet.getDouble("Amount");
            String date = resultSet.getString("Date");
            
            
            Ticket ticket = new Ticket();
            
            ticket.setTicketID(ticketID);
            ticket.setAdult(adult);
            ticket.setSenior(senior);
            ticket.setChildren(children);
            ticket.setAmount(amount);
            ticket.setDate(date);
            
            tickets.add(ticket);
        }
		
		conn.close();
		
		return tickets;
	}
	
	
	public void insertTicket(Ticket ticket) throws ClassNotFoundException, SQLException
	{
		Connection conn = MyDatabase.doConnection();
		
		String sql = "INSERT INTO ticket (AdultQuantity,SeniorCitizenQuantity,ChildrenQuantity,Amount,Date,CustomerID) VALUES (?,?,?,?,?,?)";
		PreparedStatement preparedStatement = conn.prepareStatement(sql);
		preparedStatement.setInt(1, ticket.getAdult());
		preparedStatement.setInt(2, ticket.getSenior());
		preparedStatement.setInt(3, ticket.getChildren());
		preparedStatement.setDouble(4, ticket.getAmount());
		preparedStatement.setString(5, ticket.getDate());
		preparedStatement.setInt(6, ticket.getCustomerID());
	
		preparedStatement.executeUpdate();

		conn.close();
	}
	
	
	public List<Ticket> searchTicket(int customerID, String date) throws ClassNotFoundException, SQLException 
	{
	    List<Ticket> tickets = new ArrayList<>();
	    Connection conn = MyDatabase.doConnection();

	    String sql = "SELECT * FROM ticket WHERE Date = ? AND CustomerID = ?";
	    PreparedStatement preparedStatement = conn.prepareStatement(sql);
	    preparedStatement.setString(1, date);
	    preparedStatement.setInt(2, customerID);

	    ResultSet resultSet = preparedStatement.executeQuery();

	    while (resultSet.next()) {
	        int ticketID = resultSet.getInt("ticketID");
	        int adult = resultSet.getInt("AdultQuantity");
	        int senior = resultSet.getInt("SeniorCitizenQuantity");
	        int children = resultSet.getInt("ChildrenQuantity");
	        double amount = resultSet.getDouble("Amount");
	        String ticketDate = resultSet.getString("Date");
	        
	        Ticket ticket = new Ticket();
	        ticket.setTicketID(ticketID);
	        ticket.setAdult(adult);
	        ticket.setSenior(senior);
	        ticket.setChildren(children);
	        ticket.setAmount(amount);
	        ticket.setDate(ticketDate);
	        
	        tickets.add(ticket);
	    }

	    conn.close();

	    return tickets;
	}
	
	public void deleteTicket(int ticketID) throws ClassNotFoundException, SQLException {
        Connection conn = MyDatabase.doConnection();

        // Delete the ticket
        String deleteSql = "DELETE FROM ticket WHERE ticketID = ?";
        try (PreparedStatement deleteStatement = conn.prepareStatement(deleteSql)) {
            deleteStatement.setInt(1, ticketID);
            deleteStatement.executeUpdate();
        }

        conn.close();
    }
	
	//pie chart
	  public List<Ticket> getTicketData(int year, int month) throws ClassNotFoundException, SQLException {
	      List<Ticket> ticketData = new ArrayList<>();
	      
	      Connection conn = MyDatabase.doConnection();
	      String sql = "SELECT * FROM ticket WHERE YEAR(Date) = ? AND MONTH(Date) = ?";
	      try (PreparedStatement preparedStatement = conn.prepareStatement(sql)) {
	          preparedStatement.setInt(1, year);
	          preparedStatement.setInt(2, month);

	          ResultSet resultSet = preparedStatement.executeQuery();

	          while (resultSet.next()) {
	              int ticketID = resultSet.getInt("ticketID");
	              int adult = resultSet.getInt("AdultQuantity");
	              int senior = resultSet.getInt("SeniorCitizenQuantity");
	              int children = resultSet.getInt("ChildrenQuantity");
	              String ticketDate = resultSet.getString("Date");

	              Ticket ticket = new Ticket();
	              ticket.setTicketID(ticketID);
	              ticket.setAdult(adult);
	              ticket.setSenior(senior);
	              ticket.setChildren(children);
	              ticket.setDate(ticketDate);

	              ticketData.add(ticket);
	          }
	      }

	      conn.close();

	      return ticketData;
	  }
}
